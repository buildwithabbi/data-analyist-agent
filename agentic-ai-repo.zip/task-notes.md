----this file content should not be includec in prompt
✅ Core Agent

⬜ Repair Loop          ← Next

⬜ Memory Scoring

⬜ Memory Retrieval

⬜ Conversation Memory

⬜ Checkpointing

⬜ Evaluation Framework

⬜ Guardrails

⬜ Human Approval

⬜ Embeddings

⬜ Vector Store

⬜ RAG

⬜ MCP

⬜ Multi-Agent

⬜ Deployment

⬜ Fine-Tuning