from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode

from .state import AgentState
from .nodes import (
    planner_node,
    executor,
    reflection_node,
    repair_node,
    memory_node,
    memory_update_node,
    validator_node,
)

from ..tools import TOOLS
from .tool_routing import route_tools
from .reflection_routing import route_reflection


builder = StateGraph(AgentState)

# -----------------------------
# Nodes
# -----------------------------

builder.add_edge(START, "memory")
builder.add_edge("memory", "planner")

builder.add_node("planner", planner_node)

builder.add_node("executor", executor)

builder.add_node("tool", ToolNode(TOOLS))

builder.add_node("reflection", reflection_node)
builder.add_node("validator", validator_node)

builder.add_node("repair", repair_node)

builder.add_node("memory", memory_node)

builder.add_node("memory_update", memory_update_node)

builder.add_edge(
    "planner",
    "executor",
)

# -----------------------------
# Executor
# -----------------------------

builder.add_conditional_edges(
    "executor",
    route_tools,
    {
        "tool": "tool",
        "end": "validator",
    },
)

# -----------------------------
# Tool
# -----------------------------

builder.add_edge(
    "tool",
    "validator",
)

builder.add_edge("validator", "reflection")

# -----------------------------
# Reflection
# -----------------------------

builder.add_conditional_edges(
    "reflection",
    route_reflection,
    {
        "repair": "repair",
        "continue_execution": "executor",
        "memory_update": "memory_update",
        "end": END,
    },
)

# -----------------------------
# Repair
# -----------------------------

builder.add_edge(
    "repair",
    "executor",
)

builder.add_edge(
    "memory_update",
    END,
)

graph = builder.compile(
    name="DataAnalystAgent",
)
