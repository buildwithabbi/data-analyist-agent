"""Console and logging helpers."""

